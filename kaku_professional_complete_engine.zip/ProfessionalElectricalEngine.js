/**
 * ========================================================
 * KAKU FIELD ESTIMATE STUDIO - Professional Electrical Engine
 * 完全版: 図面データ解析・器具自動配置・全配線自動結線モジュール
 * ========================================================
 */

export class ProfessionalElectricalAutoEngine {
  constructor(roomDataList) {
    this.rooms = roomDataList || [];
    this.symbols = [];
    this.wires = [];
  }

  // 図面全体の全自動プロット実行
  execute() {
    this.symbols = [];
    this.wires = [];

    this.rooms.forEach((room) => {
      const isToilet = room.name?.includes('トイレ') || room.hasToilet;
      const isWashroom = room.name?.includes('洗面') || room.name?.includes('脱衣');
      const centerX = room.x + room.width / 2;
      const centerY = room.y + room.height / 2;

      // 1. 照明 (DL / センサ付LED)
      const lightId = `light_${room.id}`;
      this.symbols.push({
        id: lightId,
        type: isToilet ? 'DL_SENSOR' : 'DL',
        x: centerX,
        y: centerY,
        label: isToilet ? '明るさセンサ' : 'DL',
        heightAttr: '',
        color: '#e11d48'
      });

      // 2. スイッチ (ドア付近の壁面へ吸着)
      const switchId = `sw_${room.id}`;
      const switchX = room.x + 16;
      const switchY = room.y + room.height - 18;
      this.symbols.push({
        id: switchId,
        type: isToilet ? 'SWITCH_SENSOR' : 'SWITCH_SINGLE',
        x: switchX,
        y: switchY,
        label: isToilet ? 'かつてにスイッチ' : 'S',
        heightAttr: 'H=1200',
        color: '#16a34a'
      });

      // 3. 水回り専用機器 (トイレ・洗面の場合：パイプファン ＆ E付コンセント)
      if (isToilet || isWashroom) {
        const fanId = `fan_${room.id}`;
        const fanX = room.x + room.width - 24;
        const fanY = room.y + 24;
        this.symbols.push({
          id: fanId,
          type: 'EXHAUST_FAN',
          x: fanX,
          y: fanY,
          label: 'パイプファン',
          heightAttr: 'H=2100',
          color: '#0284c7'
        });

        // スイッチから換気扇への実線配線
        this.wires.push({
          d: `M ${switchX} ${switchY} L ${fanX} ${fanY}`,
          type: 'SOLID',
          color: '#e11d48'
        });
      }

      // 4. 一般コンセント (壁面吸着)
      const outletId = `outlet_${room.id}`;
      const outletX = room.x + room.width - 12;
      const outletY = centerY;
      this.symbols.push({
        id: outletId,
        type: 'OUTLET_2P',
        x: outletX,
        y: outletY,
        label: isToilet ? 'E付 (温水洗浄便座)' : '2口',
        heightAttr: 'H=300',
        color: '#2563eb'
      });

      // 5. 配線結線 (スイッチ ↔ 照明：実線赤 / 照明 ↔ コンセント：破線黒)
      this.wires.push({
        d: `M ${switchX} ${switchY} Q ${(switchX + centerX) / 2} ${Math.min(switchY, centerY) - 15} ${centerX} ${centerY}`,
        type: 'SOLID',
        color: '#e11d48'
      });

      this.wires.push({
        d: `M ${centerX} ${centerY} L ${outletX} ${outletY}`,
        type: 'DASHED',
        color: '#475569'
      });
    });

    return {
      symbols: this.symbols,
      wires: this.wires
    };
  }
}

// SVGレンダリングエンジン
export function renderProfessionalPlanSVG(symbols, wires) {
  const wireSvg = wires.map(w => `
    <path d="${w.d}" fill="none" stroke="${w.color}" stroke-width="1.5" ${w.type === 'DASHED' ? 'stroke-dasharray="4,3"' : ''} />
  `).join('');

  const symbolSvg = symbols.map(s => {
    let shape = '';
    if (s.type === 'DL' || s.type === 'DL_SENSOR') {
      shape = `
        <circle r="10" fill="#ffffff" stroke="${s.color}" stroke-width="1.5"/>
        <text x="0" y="3" text-anchor="middle" font-size="8" font-weight="bold" fill="${s.color}">DL</text>
        ${s.type === 'DL_SENSOR' ? '<circle r="13" fill="none" stroke="#e11d48" stroke-width="1" stroke-dasharray="2,2"/>' : ''}
      `;
    } else if (s.type === 'EXHAUST_FAN') {
      shape = `
        <rect x="-10" y="-10" width="20" height="20" fill="#ffffff" stroke="${s.color}" stroke-width="1.5"/>
        <circle r="5" fill="none" stroke="${s.color}" stroke-width="1"/>
        <path d="M -3 -3 L 3 3 M -3 3 L 3 -3" stroke="${s.color}" stroke-width="1"/>
      `;
    } else if (s.type === 'OUTLET_2P') {
      shape = `
        <circle r="9" fill="#ffffff" stroke="${s.color}" stroke-width="1.5"/>
        <line x1="-3" y1="-4" x2="-3" y2="4" stroke="${s.color}" stroke-width="1.5"/>
        <line x1="3" y1="-4" x2="3" y2="4" stroke="${s.color}" stroke-width="1.5"/>
      `;
    } else {
      shape = `
        <circle r="8" fill="${s.color}"/>
        <text x="0" y="3" text-anchor="middle" font-size="8" font-weight="bold" fill="#ffffff">S</text>
      `;
    }

    return `
      <g transform="translate(${s.x}, ${s.y})">
        ${shape}
        ${s.heightAttr ? `<text x="0" y="-13" text-anchor="middle" font-size="7" fill="#dc2626" font-weight="bold">${s.heightAttr}</text>` : ''}
        <text x="0" y="20" text-anchor="middle" font-size="7.5" fill="#334155">${s.label}</text>
      </g>
    `;
  }).join('');

  return `<svg viewBox="0 0 800 600" xmlns="http://www.w3.org/2000/svg" style="background:#fff; width:100%; height:auto;">
    <g id="wires">${wireSvg}</g>
    <g id="symbols">${symbolSvg}</g>
  </svg>`;
}
