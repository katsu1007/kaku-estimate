import React, { useState } from 'react';

// 電気記号コンポーネント (JIS C 0303 準拠デザイン)
export const ElectricalSymbol = ({ type, x, y, rotation = 0 }) => {
  const size = 28;
  const half = size / 2;

  switch (type) {
    case 'DL': // ダウンライト (丸にDL表記)
      return (
        <g transform={`translate(${x}, ${y})`}>
          <circle r={half} fill="#ffffff" stroke="#e11d48" strokeWidth="2" />
          <text
            x="0"
            y="4"
            textAnchor="middle"
            fontSize="10"
            fontWeight="bold"
            fill="#e11d48"
            style={{ userSelect: 'none' }}
          >
            DL
          </text>
        </g>
      );

    case 'outlet': // ダブルコンセント (壁面に寄せる配置)
      return (
        <g transform={`translate(${x}, ${y}) rotate(${rotation})`}>
          <circle r={half} fill="#ffffff" stroke="#2563eb" strokeWidth="2" />
          <line x1={-half / 3} y1={-half / 2} x2={-half / 3} y2={half / 2} stroke="#2563eb" strokeWidth="2" strokeLinecap="round" />
          <line x1={half / 3} y1={-half / 2} x2={half / 3} y2={half / 2} stroke="#2563eb" strokeWidth="2" strokeLinecap="round" />
        </g>
      );

    case 'switch': // 片切スイッチ (黒丸 S)
      return (
        <g transform={`translate(${x}, ${y})`}>
          <circle r={half * 0.75} fill="#16a34a" />
          <text
            x="0"
            y="3.5"
            textAnchor="middle"
            fontSize="9"
            fontWeight="bold"
            fill="#ffffff"
            style={{ userSelect: 'none' }}
          >
            S
          </text>
        </g>
      );

    default:
      return <circle cx={x} cy={y} r={4} fill="#6b7280" />;
  }
};

// 自動配線・器具自動配置ロジック付き図面キャンバス
export const ElectricalLayoutCanvas = ({ zones, width = 800, height = 600 }) => {
  // 自動配置された器具・記号と配線ルートの算出
  const generateElectricalData = () => {
    let symbols = [];
    let wiringPaths = [];

    zones.forEach((zone) => {
      // 区画（部屋）の中心座標
      const centerX = zone.x + zone.width / 2;
      const centerY = zone.y + zone.height / 2;

      // 1. 各小区画（区画13〜18等）にDL（ダウンライト）を自動配置
      const dlSymbol = {
        id: `dl-${zone.id}`,
        type: 'DL',
        x: centerX,
        y: centerY,
        zoneId: zone.id
      };
      symbols.push(dlSymbol);

      // 2. 壁際（間仕切り側）にコンセントを自動配置
      const outletSymbol = {
        id: `outlet-${zone.id}`,
        type: 'outlet',
        x: zone.x + zone.width - 6,
        y: centerY,
        rotation: 90,
        zoneId: zone.id
      };
      symbols.push(outletSymbol);

      // 3. 配線自動生成 (スイッチ〜DL、DL〜隣接DLへの天井配線イナズマ/円弧パス)
      // 例: 隣接する区画への渡り配線 (Bezier Curve)
      if (zone.nextZoneCenter) {
        const pathData = `M ${centerX} ${centerY} Q ${(centerX + zone.nextZoneCenter.x) / 2} ${centerY - 15} ${zone.nextZoneCenter.x} ${zone.nextZoneCenter.y}`;
        wiringPaths.push({
          id: `wire-${zone.id}`,
          d: pathData
        });
      }
    });

    return { symbols, wiringPaths };
  };

  const { symbols, wiringPaths } = generateElectricalData();

  return (
    <svg width={width} height={height} style={{ background: '#fcfbf9', border: '1px solid #e5e7eb' }}>
      {/* 1. 配線ライン（破線描画） */}
      <g id="wiring-layer">
        {wiringPaths.map((wire) => (
          <path
            key={wire.id}
            d={wire.d}
            fill="none"
            stroke="#2563eb"
            strokeWidth="1.5"
            strokeDasharray="4 3"
          />
        ))}
      </g>

      {/* 2. 電気記号レイヤー */}
      <g id="symbols-layer">
        {symbols.map((sym) => (
          <ElectricalSymbol
            key={sym.id}
            type={sym.type}
            x={sym.x}
            y={sym.y}
            rotation={sym.rotation}
          />
        ))}
      </g>
    </svg>
  );
};
