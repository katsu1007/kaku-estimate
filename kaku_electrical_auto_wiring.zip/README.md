# KAKU - 自動配線 & 電気記号描画モジュール

図面上の器具（便器、洗面、流し等）に合わせて、単なるドット（丸印）ではなく、
JIS規格に準拠した**「DL（ダウンライト）」や「2口コンセント」の記号アイコン**および**機器間の自動配線ライン**を描画するコードパッケージです。

## 収録ファイル
1. `ElectricalLayout.jsx` : Webブラウザ/React (SVG) 用の記号描画 & 自動配線コンポーネント
2. `ElectricalLayout.swift` : iOS (SwiftUI Canvas) 用の記号描画 & 自動配線ビュー

## 導入方法

### React / Next.js の場合
`ElectricalLayout.jsx` をプロジェクトの `components` フォルダに配置し、
各区画の境界座標（x, y, width, height）配列を渡して呼び出してください。

```jsx
import { ElectricalLayoutCanvas } from './ElectricalLayout';

<ElectricalLayoutCanvas zones={zoneList} width={800} height={600} />
```

### SwiftUI / iOS の場合
`ElectricalLayout.swift` を `kaku-estimate` プロジェクトに追加し、
図面ビューの上に `.overlay(ElectricalLayoutView(zones: zones))` として重ね合わせて使用します。
