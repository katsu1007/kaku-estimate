import SwiftUI

// MARK: - 電気記号種別
enum ElectricalSymbolType {
    case downlight
    case outlet
    case switchSymbol
}

// MARK: - 電気記号描画ビュー (SwiftUI)
struct ElectricalSymbolView: View {
    let type: ElectricalSymbolType
    var rotation: Double = 0.0

    var body: some View {
        ZStack {
            switch type {
            case .downlight:
                Circle()
                    .stroke(Color.red, lineWidth: 2)
                    .background(Circle().fill(Color.white))
                    .frame(width: 26, height: 26)
                Text("DL")
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(.red)

            case .outlet:
                ZStack {
                    Circle()
                        .stroke(Color.blue, lineWidth: 2)
                        .background(Circle().fill(Color.white))
                        .frame(width: 26, height: 26)
                    HStack(spacing: 5) {
                        Capsule().frame(width: 2, height: 12)
                        Capsule().frame(width: 2, height: 12)
                    }
                    .foregroundColor(.blue)
                }
                .rotationEffect(.degrees(rotation))

            case .switchSymbol:
                ZStack {
                    Circle()
                        .fill(Color.green)
                        .frame(width: 20, height: 20)
                    Text("S")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.white)
                }
            }
        }
    }
}

// MARK: - 区画データ構造体
struct ZoneData: Identifiable {
    let id: String
    let rect: CGRect
    let name: String
}

// MARK: - 自動配線 & 電気記号レイヤー (SwiftUI)
struct ElectricalLayoutView: View {
    let zones: [ZoneData]

    var body: some View {
        Canvas { context, size in
            // 1. 自動配線ライン（イナズマ/曲線の描画）
            for i in 0..<(zones.count - 1) {
                let startPoint = CGPoint(x: zones[i].rect.midX, y: zones[i].rect.midY)
                let endPoint = CGPoint(x: zones[i+1].rect.midX, y: zones[i+1].rect.midY)

                var path = Path()
                path.move(to: startPoint)
                // 制御点を打って綺麗な配線カーブを作成
                let controlPoint = CGPoint(
                    x: (startPoint.x + endPoint.x) / 2,
                    y: min(startPoint.y, endPoint.y) - 20
                )
                path.addQuadCurve(to: endPoint, control: controlPoint)

                // 点線スタイルで配線を打つ
                let strokeStyle = StrokeStyle(lineWidth: 1.5, dash: [4, 3])
                context.stroke(path, with: .color(.blue), style: strokeStyle)
            }
        }
        .overlay(
            // 2. 自動配置された記号レイヤー
            ForEach(zones) { zone in
                Group {
                    // 中心にDLを配置
                    ElectricalSymbolView(type: .downlight)
                        .position(x: zone.rect.midX, y: zone.rect.midY)

                    // 壁際にコンセントを配置
                    ElectricalSymbolView(type: .outlet, rotation: 90)
                        .position(x: zone.rect.maxX - 8, y: zone.rect.midY)
                }
            }
        )
    }
}
