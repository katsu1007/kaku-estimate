import initWasm, { detectFileFormat, readCadDocument, readDxfDocument } from "./wasm/ezjww_wasm.js";
import "./style.css";

const $ = (s) => document.querySelector(s);
const fileInput = $("#file");
const status = $("#status");
const canvas = $("#canvas");
let wasmPromise;

async function ensureWasm() {
  wasmPromise ??= initWasm();
  await wasmPromise;
}

fileInput.addEventListener("change", async () => {
  const file = fileInput.files?.[0];
  if (!file) return;
  status.textContent = file.name + " を解析しています…";
  try {
    await ensureWasm();
    const bytes = new Uint8Array(await file.arrayBuffer());
    const detected = detectFileFormat(bytes);
    if (!detected) throw new Error("JWW/JWC/JWS形式を確認できませんでした");
    const started = performance.now();
    const cad = readCadDocument(bytes);
    const elapsed = Math.round(performance.now() - started);
    const doc = cad.document;
    const dxf = readDxfDocument(bytes, true, 32, "paper_millimeters");
    render(file, cad, dxf, elapsed);
    status.textContent = "解析完了 · " + file.name;
  } catch (error) {
    console.error(error);
    status.textContent = "解析エラー: " + (error?.message || String(error));
  }
});

function render(file, cad, dxf, elapsed) {
  const doc = cad.document;
  $("#format").textContent = cad.format.toUpperCase() + (doc.header?.version ? " / Ver." + doc.header.version : "");
  const groups = doc.header?.layer_groups || [];
  const layerCount = groups.reduce((n, g) => n + (g.layers?.length || 0), 0);
  $("#stats").innerHTML = [
    ["図形数", doc.entities?.length ?? 0],
    ["ブロック定義", doc.block_defs?.length ?? 0],
    ["レイヤー", layerCount]
  ].map(([label,value]) => `<article><small>${label}</small><strong>${Number(value).toLocaleString("ja-JP")}</strong></article>`).join("");
  $("#layers").innerHTML = groups.map((g,i) => {
    const groupName = typeof g.name === "string" ? g.name : (g.name?.text || "");
    return `<div class="layer-group"><b>${esc(groupName || "グループ " + (i+1))}</b><div class="layer-chips">${(g.layers||[]).map((l)=>{const n=typeof l.name==="string"?l.name:(l.name?.text||"");return n.trim()?'<span>'+esc(n)+'</span>':""}).join("")}</div></div>`;
  }).join("") || '<div class="empty">レイヤー情報なし</div>';
  const counts = doc.entity_counts || {};
  $("#counts").innerHTML = Object.entries(counts).sort((a,b)=>b[1]-a[1]).map(([type,n])=>`<div class="count-row"><span>${esc(type)}</span><b>${Number(n).toLocaleString("ja-JP")}</b></div>`).join("") || '<div class="empty">図形情報なし</div>';
  const important = ["トイレブース","パーティション","衛生設備機器","器具","躯体","壁仕上ライン","寸法"];
  const allNames = groups.flatMap(g=>(g.layers||[]).map(l=>typeof l.name==="string"?l.name:(l.name?.text||"")));
  const found = important.filter(k=>allNames.some(n=>n.includes(k)));
  status.textContent = `解析 ${elapsed}ms · ${dxf.entities?.length ?? 0}件を描画用データに変換 · 関連レイヤー: ${found.join(" / ") || "未検出"}`;
  draw(dxf.entities || []);
}

function draw(entities) {
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, Math.floor(rect.width*dpr));
  canvas.height = Math.max(1, Math.floor(rect.height*dpr));
  const ctx = canvas.getContext("2d");
  ctx.setTransform(dpr,0,0,dpr,0,0);
  const w=rect.width,h=rect.height;
  ctx.fillStyle="#101e25";ctx.fillRect(0,0,w,h);
  const lines=[];
  for(const e of entities){
    if(e.type==="LINE" && [e.x1,e.y1,e.x2,e.y2].every(Number.isFinite)) lines.push([e.x1,e.y1,e.x2,e.y2]);
  }
  if(!lines.length){ctx.fillStyle="#a8bac0";ctx.fillText("表示可能な直線データがありません",20,30);return;}
  const xs=lines.flatMap(l=>[l[0],l[2]]),ys=lines.flatMap(l=>[l[1],l[3]]);
  const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
  const scale=Math.min((w-32)/Math.max(1,maxX-minX),(h-32)/Math.max(1,maxY-minY));
  const ox=(w-(maxX-minX)*scale)/2,oy=(h-(maxY-minY)*scale)/2;
  ctx.strokeStyle="#c7d7d8";ctx.lineWidth=1;ctx.beginPath();
  for(const [x1,y1,x2,y2] of lines){ctx.moveTo(ox+(x1-minX)*scale,h-oy-(y1-minY)*scale);ctx.lineTo(ox+(x2-minX)*scale,h-oy-(y2-minY)*scale);}
  ctx.stroke();
}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
