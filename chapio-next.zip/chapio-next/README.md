# ちゃぴお JWW解析アプリ（次版）

iPhone Safariで開くことを想定したブラウザアプリです。JWW/JWC/JWSを端末内のWebAssemblyで読み込みます。

## この版で行うこと
- ezjww 0.7.11のWebAssemblyパーサーを利用
- 元図形数・DXF変換後図形数・ブロック定義数の表示
- レイヤーグループとレイヤー別の図形数表示
- LINE / CIRCLE / ARC / ELLIPSE / SOLID / POINT / TEXTのプレビュー
- 図面の拡大縮小・ドラッグ移動
- トイレブース、パーティション、衛生設備機器などの重要レイヤー検出

## まだ実装していないこと
個室境界の自動閉領域認識、便器と個室の対応付け、寸法・面積の自動算出は未実装です。表示できたことを数量拾いの成功とは扱いません。

## GitHub Pages
GitHub Actionsは `monozukuri-ai/ezjww` の `crates/ezjww-wasm` をWebAssemblyへビルドし、Viteで公開します。`main`へpush後、Actionsの完了を待ってPages URLを開いてください。
