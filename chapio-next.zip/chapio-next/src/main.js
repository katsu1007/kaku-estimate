import initWasm, { detectFileFormat, readCadDocument, readDxfDocument } from './wasm/ezjww_wasm.js';
import './style.css';

const $ = (s) => document.querySelector(s);
const fileInput = $('#file'), canvas = $('#canvas'), status = $('#status');
let wasmReady = null, parsed = null, view = { scale: 1, x: 0, y: 0, fit: true }, pointer = null;
const fmt = n => new Intl.NumberFormat('ja-JP').format(n ?? 0);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function ensureWasm(){ if(!wasmReady) wasmReady = initWasm().then(()=>true).catch(e=>{wasmReady=null;throw e}); return wasmReady; }
fileInput.addEventListener('change', async()=>{const f=fileInput.files?.[0];if(!f)return;status.textContent=`${f.name} を読み込み中…`;try{await ensureWasm();const bytes=new Uint8Array(await f.arrayBuffer());const format=detectFileFormat(bytes);if(!format)throw new Error('JWW/JWC/JWS形式を認識できません');const t=performance.now();const cad=readCadDocument(bytes);const dxf=readDxfDocument(bytes,true,32,'paper_millimeters');parsed={file:f.name,format,cad,dxf,elapsed:performance.now()-t};view.fit=true;render();status.textContent=`解析完了 · ${f.name} · ${parsed.elapsed.toFixed(0)}ms`;}catch(e){console.error(e);status.textContent=`解析エラー: ${e?.message||e}`;parsed=null;render();}});

function render(){
  $('#sourceCount').textContent=parsed?fmt(parsed.cad.document.entities.length):'—';
  $('#dxfCount').textContent=parsed?fmt(parsed.dxf.entities.length):'—';
  $('#blockCount').textContent=parsed?fmt(parsed.cad.document.block_defs?.length||0):'—';
  $('#format').textContent=parsed?`${parsed.format.toUpperCase()}${parsed.cad.document.header?.version?` / Ver.${parsed.cad.document.header.version}`:''}`:'未読込';
  renderLayers();renderCounts();draw();
}
function layerName(v){return typeof v==='string'?v:(v?.text||'');}
function renderLayers(){const target=$('#layers'),important=$('#importantLayers');if(!parsed){target.textContent='未読込';important.textContent='図面を読み込むと確認します';return;}
 const doc=parsed.cad.document, groups=doc.header?.layer_groups||[];const hot=['トイレブース','パーティション','衛生設備機器','器具','躯体','壁仕上ライン','寸法'];
 const all=groups.flatMap((g,gi)=>(g.layers||[]).map((l,li)=>({name:layerName(l.name),gi,li}))).filter(x=>x.name.trim());
 const found=hot.filter(k=>all.some(x=>x.name.includes(k)));
 important.innerHTML=found.length?found.map(n=>`<span>${esc(n)}</span>`).join(''):'該当レイヤーなし';
 target.innerHTML=groups.map((g,gi)=>{const gname=layerName(g.name)||`グループ ${gi+1}`;const items=(g.layers||[]).map((l,li)=>{const name=layerName(l.name);if(!name.trim())return '';const n=(doc.entities||[]).filter(e=>e.base?.layer_group===gi&&e.base?.layer===li).length;const isHot=hot.some(k=>name.includes(k));return `<span class="layer-chip ${isHot?'hot':''}">${esc(name)}<b>${fmt(n)}</b></span>`;}).join('');return `<div class="layer-group"><div class="group-title">${esc(gname)} · 縮尺 1:${esc(g.scale??1)}</div><div class="layer-chips">${items||'<span class="empty">名称なし</span>'}</div></div>`;}).join('')||'<div class="empty">レイヤー情報なし</div>';
}
function renderCounts(){const target=$('#counts');if(!parsed){target.textContent='未読込';return;}const counts=parsed.cad.document.entity_counts||{};const rows=Object.entries(counts).sort((a,b)=>b[1]-a[1]);target.innerHTML=rows.map(([k,v])=>`<div class="count-row"><span>${esc(k)}</span><b>${fmt(v)}</b></div>`).join('')||'<div class="empty">図形情報なし</div>';}

function boundsOf(entities){let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;const add=(x,y)=>{if(Number.isFinite(x)&&Number.isFinite(y)){minX=Math.min(minX,x);minY=Math.min(minY,y);maxX=Math.max(maxX,x);maxY=Math.max(maxY,y);}};
 for(const e of entities){if(num(e,'x1','y1','x2','y2')){add(e.x1,e.y1);add(e.x2,e.y2);}if(num(e,'x3','y3','x4','y4')){add(e.x3,e.y3);add(e.x4,e.y4);}if(num(e,'x','y'))add(e.x,e.y);if(num(e,'center_x','center_y','radius')){add(e.center_x-e.radius,e.center_y-e.radius);add(e.center_x+e.radius,e.center_y+e.radius);}if(e.type==='ELLIPSE'&&num(e,'center_x','center_y','major_axis_x','major_axis_y','minor_ratio')){const rx=Math.hypot(e.major_axis_x,e.major_axis_y*e.minor_ratio),ry=Math.hypot(e.major_axis_y,e.major_axis_x*e.minor_ratio);add(e.center_x-rx,e.center_y-ry);add(e.center_x+rx,e.center_y+ry);}}
 return Number.isFinite(minX)?{minX,minY,maxX,maxY}:null;
}
function num(o,...ks){return ks.every(k=>typeof o[k]==='number'&&Number.isFinite(o[k]));}
function draw(){const r=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1,w=r.width,h=r.height;canvas.width=Math.max(1,Math.floor(w*dpr));canvas.height=Math.max(1,Math.floor(h*dpr));const c=canvas.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.fillStyle='#f7f8f8';c.fillRect(0,0,w,h);if(!parsed){c.fillStyle='#78858b';c.textAlign='center';c.fillText('JWW図面を選択してください',w/2,h/2);return;}
 const ents=parsed.dxf.entities||[],b=boundsOf(ents);if(!b){c.fillStyle='#78858b';c.fillText('表示できる図形データがありません',w/2,h/2);return;}const pad=20,mw=Math.max(1,b.maxX-b.minX),mh=Math.max(1,b.maxY-b.minY),fit=Math.min((w-pad*2)/mw,(h-pad*2)/mh);if(view.fit){view.scale=fit;view.x=0;view.y=0;view.fit=false;}const scale=view.scale,ox=(w-mw*scale)/2+view.x,oy=(h-mh*scale)/2+view.y;const p=(x,y)=>[ox+(x-b.minX)*scale,h-(oy+(y-b.minY)*scale)];
 c.strokeStyle='#dfe5e6';c.lineWidth=1;c.beginPath();for(let x=0;x<w;x+=48){c.moveTo(x,0);c.lineTo(x,h);}for(let y=0;y<h;y+=48){c.moveTo(0,y);c.lineTo(w,y);}c.stroke();c.lineWidth=Math.max(.7,Math.min(2,scale*.8));c.lineJoin='round';c.lineCap='round';
 for(const e of ents){const color=({1:'#253b49',2:'#b54d46',3:'#3d8767',4:'#407ca8',5:'#a17b39',6:'#8a6ca7',7:'#4d777a'})[Math.abs(e.color)%8]||'#344b58';c.strokeStyle=color;c.fillStyle=color;c.setLineDash(e.line_type?.includes('DASH')?[4,3]:[]);drawEntity(c,e,p,scale);}c.setLineDash([]);
}
function drawEntity(c,e,p,s){
 if(e.type==='LINE'&&num(e,'x1','y1','x2','y2')){const a=p(e.x1,e.y1),b=p(e.x2,e.y2);c.beginPath();c.moveTo(...a);c.lineTo(...b);c.stroke();return;}
 if(e.type==='CIRCLE'&&num(e,'center_x','center_y','radius')){const a=p(e.center_x,e.center_y);c.beginPath();c.arc(a[0],a[1],Math.max(.5,e.radius*s),0,Math.PI*2);c.stroke();return;}
 if(e.type==='ARC'&&num(e,'center_x','center_y','radius')){const start=(e.start_angle||0)*Math.PI/180,end=(e.end_angle||0)*Math.PI/180;let span=end-start;if(span<0)span+=Math.PI*2;polyline(c,Array.from({length:Math.max(9,Math.ceil(span*24))+1},(_,i)=>{const a=start+span*i/Math.max(8,Math.ceil(span*24));return p(e.center_x+e.radius*Math.cos(a),e.center_y+e.radius*Math.sin(a));}));return;}
 if(e.type==='ELLIPSE'&&num(e,'center_x','center_y','major_axis_x','major_axis_y','minor_ratio')){const ax=e.major_axis_x,ay=e.major_axis_y,steps=72,t0=e.start_param??0,t1=e.end_param??Math.PI*2;polyline(c,Array.from({length:steps+1},(_,i)=>{const t=t0+(t1-t0)*i/steps;return p(e.center_x+ax*Math.cos(t)-ay*e.minor_ratio*Math.sin(t),e.center_y+ay*Math.cos(t)+ax*e.minor_ratio*Math.sin(t));}));return;}
 if(e.type==='SOLID'&&num(e,'x1','y1','x2','y2','x3','y3','x4','y4')){const pts=[[e.x1,e.y1],[e.x2,e.y2],[e.x3,e.y3],[e.x4,e.y4]].map(v=>p(...v));c.globalAlpha=.24;c.beginPath();c.moveTo(...pts[0]);pts.slice(1).forEach(v=>c.lineTo(...v));c.closePath();c.fill();c.globalAlpha=1;c.stroke();return;}
 if(e.type==='POINT'&&num(e,'x','y')){const a=p(e.x,e.y);c.beginPath();c.arc(a[0],a[1],2,0,Math.PI*2);c.fill();return;}
 if(e.type==='TEXT'&&num(e,'x','y')){const a=p(e.x,e.y);c.save();c.translate(a[0],a[1]);c.rotate(-(e.rotation||0)*Math.PI/180);c.font=`${Math.max(7,Math.min(18,(e.height||3)*s))}px sans-serif`;c.fillText(e.content||'',0,0);c.restore();}
}
function polyline(c,pts){if(!pts.length)return;c.beginPath();c.moveTo(...pts[0]);for(const v of pts.slice(1))c.lineTo(...v);c.stroke();}

canvas.addEventListener('wheel',e=>{if(!parsed)return;e.preventDefault();const factor=e.deltaY<0?1.12:.89;view.scale=Math.max(.03,Math.min(1000,view.scale*factor));draw();},{passive:false});
canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);pointer={x:e.clientX,y:e.clientY,ox:view.x,oy:view.y};});
canvas.addEventListener('pointermove',e=>{if(!pointer)return;view.x=pointer.ox+e.clientX-pointer.x;view.y=pointer.oy+e.clientY-pointer.y;draw();});
for(const ev of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(ev,()=>pointer=null);
window.addEventListener('resize',()=>{view.fit=true;draw();});
render();
